# 串口发送模块
from maix import uart, pinmap

pinmap.set_pin_function("A17", "UART0_RX")
pinmap.set_pin_function("A16", "UART0_TX")
_serial = uart.UART("/dev/ttyS0", 115200)


def send_circle(cx, cy, r, label_num=1):
    _serial.write(f"id={label_num}, cx={cx}, cy={cy}, r={r}\r\n".encode())


def send_none():
    _serial.write(b"no target\r\n")
