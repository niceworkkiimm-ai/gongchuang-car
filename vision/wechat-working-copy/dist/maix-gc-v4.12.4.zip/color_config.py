# 摄像头分辨率
CAM_W = 320
CAM_H = 240


# 最小识别面积
MIN_AREA = 200


# LAB阈值
# 格式：
# [L_min,L_max,A_min,A_max,B_min,B_max]


COLOR_LAB ={

    1:{
         "name":"Red",
         "lab":[0,80,40,80,10,80]
     },

    2:{
         "name":"Yellow",
         "lab":[40,255,-10,45,40,120]
     },
    3:{
         "name":"Blue",
         "lab":[0, 80, 22, 60, -90, -25]
     },
    4:{
         "name":"Green",
         "lab":[15,200,-90,-18,-10,80]
     },
    5:{
         "name":"Black",
         "lab":[0,30,-12,12,-12,12]
     },
    6:{
         "name":"Cyan",
         "lab":[18, 120, 5, 20, -75, -8]
     }

}
