.\objects\core_cm3.o: ..\CMSIS\core_cm3.c
.\objects\core_cm3.o: E:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
