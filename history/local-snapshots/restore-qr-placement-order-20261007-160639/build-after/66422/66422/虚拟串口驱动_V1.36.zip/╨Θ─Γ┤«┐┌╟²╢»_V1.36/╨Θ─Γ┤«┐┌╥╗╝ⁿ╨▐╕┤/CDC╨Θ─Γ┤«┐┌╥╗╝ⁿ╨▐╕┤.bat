@echo off
:color 3e
ver|find "5.0" >nul
if not errorlevel 1 goto Windows2K
ver|find "5.1" >nul
if not errorlevel 1 goto WindowsXP
ver|find "5.2" >nul
if not errorlevel 1 goto Windows2K3
ver|find "6.0" >nul
if not errorlevel 1 goto WindowsVista
ver|find "6.1" >nul
if not errorlevel 1 goto Windows7
ver|find "6.2" >nul
if not errorlevel 1 goto Windows8
(echo Not support this Operating System)
goto eof
:Windows2K
:WindowsXP
:Windows2K3
echo Windows2K/WindowsXP/Windows2K3
    if not exist "%windir%\system32\drivers\usbser.sys" (
	copy /y xp\usbser.sys  %windir%\system32\drivers\usbser.sys
	goto check
    ) else (
	echo usbser exist
	goto eof
    )
:WindowsVista
echo WindowsVista
goto eof
:Windows7
:Windows8
echo Windows7/8
if /i "%PROCESSOR_IDENTIFIER:~0,3%"=="X86" (goto X86) else (goto X64)
:X86
echo Windows7/8 X86
    if not exist "%windir%\system32\drivers\usbser.sys" (
	copy /y win7_x86\usbser.sys %windir%\system32\drivers\usbser.sys
	goto check
    ) else (
	echo usbser exist
        goto eof
    )
:X64
echo Windows7/8 X64
    if not exist "%windir%\system32\drivers\usbser.sys" (
	copy /y win7_x64\usbser.sys %windir%\system32\drivers\usbser.sys
	goto check
    ) else (
	echo usbser exist
	goto eof
    )
:check
if not exist "%windir%\system32\drivers\usbser.sys" (	
    	echo A file of usbser copy failed please complete manually 
	echo Repair failed!!!!!
	goto eof1
	) else (
	  echo A file of usbser copy succeed
	)
:eof
echo Repair is complete
:eof1
pause

